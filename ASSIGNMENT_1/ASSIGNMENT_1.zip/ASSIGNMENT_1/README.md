# COS314-IntroToAI Assignemnt 1
1. Main.java contains a main for SA and ILS (SA main is commented out)
2. ILS_txt.txt contains the results of each iteration for the Iterated Local Search
3. SA_txt.txt contains the results of each iteration for the Simulated Annealing Algorithm
4. ILS.java contains the algorithm for Iterated Local Search
5. SA.java contains the code and Algorithm for the Simulated Annealing